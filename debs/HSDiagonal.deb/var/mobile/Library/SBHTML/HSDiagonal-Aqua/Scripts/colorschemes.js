//apply color scheme based on which scheme is selected

//First create objects to easily index proper colors

/*SCHEME OBJECT DECLARATIONS*/
let GrayScale = {
    BGColor: "#707070", //lightgray
    AccentColor: "#DCDCDC", //Offwhite
    Shadow: "#535353", //DarkGray
    Text: "#FAFAFF" //White
  },
  Maroon = {
    BGColor: "#07010a", //black
    AccentColor: "#8c0e33", //Pink
    Shadow: "#170420", //DeepPurple
    Text: "#FFFFFF" //White
  },
  Sunflower = {
    BGColor: "#ffea00", //BrightYellow
    AccentColor: "#ff6d00", //DarkOrange
    Shadow: "#ff8800", //LightOrange
    Text: "#93896f" //Tan
  },
  Peach = {
    BGColor: "#f0a390", //DarkPeach
    AccentColor: "#e76f51", //PeachOrange
    Shadow: "#f5c4b8", //LightPeach
    Text: "#264653" //DarkTeal
  },
  Aqua = {
    BGColor: "#77c1b7", //LightTeal
    AccentColor: "#2a9d8f", //Teal
    Shadow: "#264653", //DeepBlue
    Text: "#dbeeec" //BlueWhite
  },
  Lavendar = {
    BGColor: "#85859d", //LavendarLightGray
    AccentColor: "#bba0ca", //Lavendar
    Shadow: "#6e6e82", //LavendarDarkGray
    Text: "#c3c3e6" //LavendarWhite
  },
  Pastel = {
    BGColor: "#eff7f6", //OffWhite
    AccentColor: "#b2f7ef", //LightBlue
    Shadow: "#f7d6e0", //Peach
    Text: "#9381ff" //Purple
  },
  Forest = {
    BGColor: "#cad2c5", //OffWhite
    AccentColor: "#84a98c", //PaleGreen
    Shadow: "#2f3e46", //DeepGreen
    Text: "#52796f" //MidGreen
  },
  Kiddie = {
    BGColor: "#82b6ff", //Blue
    AccentColor: "#ff9668", //Pink
    Shadow: "#ff5994", //Orange
    Text: "#eaeaea" //OffWhite
  },
  Bubblegum = {
    BGColor: "#ffb6ee", //LightPink
    AccentColor: "#b6fcfe", //LightBlue
    Shadow: "#51ddff", //DarkBlue
    Text: "#e96083" //HotPink
  },
  Midnight = {
    BGColor: "#16324f", //DarkBlue
    AccentColor: "#2a628f", //MidBlue
    Shadow: "#13293d", //BlackBlue
    Text: "#fafaff" //White
  },
  Neon = {
    BGColor: "#000300", //Black
    AccentColor: "#ff206e", //HotPink
    Shadow: "#41ead4", //Teal
    Text: "#fbff12" //White
  },
  Vaporwave = {
    BGColor: "#0098a4", //Purple
    AccentColor: "#00ffff", //LightBlue
    Shadow: "#812d69", //Teal
    Text: "#ffffff" //White
  }
$(document).ready(function(){
  switch(Scheme) {
      case("GrayScale"):
        CurrentTheme = GrayScale;
        break;
      case("Maroon"):
        CurrentTheme = Maroon;
        break;
      case("Sunflower"):
        CurrentTheme = Sunflower;
        break;
      case("Peach"):
        CurrentTheme = Peach;
        break;
      case("Aqua"):
        CurrentTheme = Aqua;
        break;
      case("Lavendar"):
        CurrentTheme = Lavendar;
        break;
      case("Pastel"):
        CurrentTheme = Pastel;
        break;
      case("Forest"):
        CurrentTheme = Forest;
        break;
      case("Kiddie"):
        CurrentTheme = Kiddie;
        break;
      case("Bubblegum"):
        CurrentTheme = Bubblegum;
        break;
      case("Midnight"):
        CurrentTheme = Midnight;
        break;
      case("Neon"):
        CurrentTheme = Neon;
        break;
      case("Vaporwave"):
        CurrentTheme = Vaporwave;
        break;
      default:
        CurrentTheme = GrayScale;
  }
  //$('.bg').css("background-color", CurrentTheme.BGColor);
  $('.shadow').css("color", CurrentTheme.Shadow);
  $('#apps').css("background-color", CurrentTheme.Shadow);
  $('.accent').css("color", CurrentTheme.AccentColor);
  $('.text').css("color", CurrentTheme.Text);
  $('.split1').css("background-image", "-webkit-linear-gradient(-45deg, "+CurrentTheme.AccentColor+" 50%, "+CurrentTheme.Shadow+" 50%)");
  $('.split2').css("background-image", "-webkit-linear-gradient(45deg, "+CurrentTheme.Shadow+" 50%, "+CurrentTheme.AccentColor+" 50%)");
});
