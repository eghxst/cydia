window.addEventListener("load", function() {
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);
// const dummyData = {
//   statusbar: {
//     signalBars: "5",
//     signalNetworkType: "LTE",
//     signamName: "Carrier",
//     wifiStrength: "0",
//     wifiBars: "0",
//     wifiName: "NETWORK",
//     bluetooth: "TRUE"
//   },
//   battery: {
//     batteryPercent: 83,
//     batteryCharging: 0,
//     ramFree: 1236,
//     ramUsed: 3200,
//     ramAvailable: 3756,
//     ramPhysical: 0
//   },
//   reminders: {
//     reminders: [
//       {
//         title: "Reminder 1",
//         dueDate: "02/17/22",
//         dueDateTimestamp: "1645135245",
//         priority: "1"
//       },
//       {
//         title: "Reminder 2",
//         dueDate: "02/18/22",
//         dueDateTimestamp: "1645203645",
//         priority: "2"
//       },
//       {
//         title: "Reminder 3",
//         dueDate: "02/20/22",
//         dueDateTimestamp: "1645336845",
//         priority: "4"
//       },
//       {
//         title: "Reminder 4",
//         dueDate: "02/25/22",
//         dueDateTimestamp: "1645783245",
//         priority: "3"
//       }
//     ]
//   },
//   events: {
//     events: [
//       {
//         title: "Lunch with Martin Smithenson",
//         location: "Event Location 1",
//         isAllDay: false,
//         date: "02/17/2022",
//         startTimeTimestamp: "1645144521",
//         endTimeTimestamp: "1645148121",
//         associatedCalendarName: "Home",
//         associatedCalendarHexColor: "#FF2968",
//       },
//       {
//         title: "Event 2",
//         location: "Event Location 2",
//         isAllDay: true,
//         date: "02/18/2022",
//         startTimeTimestamp: "1645198521",
//         endTimeTimestamp: "1645209321",
//         associatedCalendarName: "Home",
//         associatedCalendarHexColor: "#FF2968",
//       },
//       {
//         title: "Event 3",
//         location: "Event Location 3",
//         isAllDay: false,
//         date: "02/19/2022",
//         startTimeTimestamp: "1645295721",
//         endTimeTimestamp: "1645303821",
//         associatedCalendarName: "School",
//         associatedCalendarHexColor: "#AAB200",
//       },
//       {
//         title: "Event 4",
//         location: "Event Location 4",
//         isAllDay: false,
//         date: "02/19/2022",
//         startTimeTimestamp: "1645307421",
//         endTimeTimestamp: "1645311021",
//         associatedCalendarName: "Work",
//         associatedCalendarHexColor: "#EEGC8A",
//       },
//     ]
//   },
//   music: {
//     artist: "Artist",
//     album: "Album",
//     title: "Song Title",
//     isPlaying: true
//   },
//   weather: {
//     address: {
//       street: "101 Main St",
//       neighbourhood: "Neighbourhood",
//       city: "City",
//       zipCode: "12345",
//       county: "Santa Clarita",
//       state: "California",
//       country: "United States",
//       countryISOCode: "US",
//     },
//     sunsetTimeFormatted: "17:08 PM",
//     sunriseTimeFormatted: "07:16 AM",
//     city: "Kutztown",
//     temperature: 60,
//     low: 41,
//     high: 61,
//     feelsLike: 58,
//     naturalCondition: "Cloudy currently. The high will be 61. Clear tonight with a low of 41",
//     dayForecasts: {
//
//     },
//     hourlyForecasts: {
//
//     },
//     latlong: "40.5129035,-72.123905",
//     celcius: null,
//     conditionCode: 1,
//     updateTimeString: "1/4/22 2:51 PM",
//     humidity: 66,
//     windChill: 58,
//     windDirection: 200,
//     windSpeed: 21,
//     visibility: 16,
//     sunsetTime: 1740,
//     precipitation24hr: 0,
//     heatIndex: 60,
//     moonPhase: 18,
//     pressure: 1015,
//     sunriseTime: 654,
//     chanceofrain: 0
//   },
//   signinginfo: {
//
//   }
// };
function conditionIcon(code) {
  let icon;
  switch(code) {
    case 1://clear
      icon = "<i class='fas fa-sun'></i>";
      break;
    case 2://fair
      icon = "<i class='fas fa-sun'></i>";
      break;
    case 3://cloudy
      icon = "<i class='fas fa-cloud'></i>";
      break;
    case 4://overcast
      icon = "<i class='fas fa-cloud-sun'></i>";
      break;
    case 5://fog
      icon = "<i class='fas fa-smog'></i>";
      break;
    case 6://freezing fog
      icon = "<i class='fas fa-smog'></i>";
      break;
    case 7://light rain
      icon = "<i class='fas fa-cloud-sun-rain'></i>";
      break;
    case 8://rain
      icon = "<i class='fas fa-cloud-rain'></i>";
      break;
    case 9://heavy rain
      icon = "<i class='fas fa-cloud-showers-heavy'></i>";
      break;
    case 10://freezing rain
      icon = "<i class='fas fa-cloud-showers-heavy'></i>";
      break;
    case 11://heavy freezing rain
      icon = "<i class='fas fa-cloud-showers-heavy'></i>";
      break;
    case 12://sleet
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 13://heavy sleet
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 14://light snowfall
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 15://snowfall
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 16://heavy snowfall
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 17://rain shower
      icon = "<i class='fas fa-cloud-rain'></i>";
      break;
    case 18://heavy rain shower
      icon = "<i class='fas fa-cloud-showers-heavy'></i>";
      break;
    case 19://sleet shower
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 20://heavy sleet shower
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 21://snow shower
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 22://heavy snow shower
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 23://lightning
      icon = "<i class='fas fa-bolt'></i>";
      break;
    case 24://hail
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 25://thunderstorm
      icon = "<i class='fas fa-bolt'></i>";
      break;
    case 26://heavy thunderstorm
      icon = "<i class='fas fa-bolt'></i>";
      break;
    case 27://storm
      icon = "<i class='fas fa-poo-storm'></i>";
      break;
    default:
      icon = "";
  }
  return icon;
}
function batteryIcon(percent) {
  let icon;
  if(percent <= 20) {
    icon = "<i class='fas fa-battery-empty'></i>";
  } else if (percent > 20 && percent <= 40) {
    icon = "<i class='fas fa-battery-quarter'></i>";
  } else if (percent > 40 && percent <= 60) {
    icon = "<i class='fas fa-battery-half'></i>";
  } else if (percent > 60 && percent <= 80) {
    icon = "<i class='fas fa-battery-three-quarters'></i>";
  } else if (percent > 80) {
    icon = "<i class='fas fa-battery-full'></i>";
  }
  return icon;
}
function unixTSConvert(timestamp, type) {
  formatted = new Date(timestamp * 1000);
  switch(type){
    case "time":
      if (Clock == "24h"){
        return formatted.getHours() + ":" + formatted.getMinutes() + ((formatted.getHours() > 12 ) ? " pm" : " am");
      }
      if (Clock == "12h"){
        return ((formatted.getHours() > 12) ? formatted.getHours()-12 : formatted.getHours()) + ":" + formatted.getMinutes() + ((formatted.getHours() > 12 ) ? " pm" : " am");
      }
      break;
    default:
      return null;
  }
}
function updateClock() {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h"){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}
if (Clock == "12h"){
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}
document.getElementById('hour').innerHTML = currentHours;
document.getElementById('minute').innerHTML = currentMinutes;
}

function init(){
updateClock();
setInterval("updateClock();", 1000);
}
