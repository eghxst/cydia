var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh"
var EventsToShow = 3; // choose max number of events to show
var TextColor = "#535353";
var AppBGColor = "#535353";
var ToneOne = "#535353";
var ToneTwo = "#DCDCDC";
