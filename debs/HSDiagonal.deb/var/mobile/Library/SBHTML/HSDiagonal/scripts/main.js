window.addEventListener("load", function() {
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);
function conditionIcon(code) {
  let icon;
  switch(code) {
    case 0: //tornado
      icon = "<i class='fas fa-poo-storm'></i>";
      break;
    case 1:  //tropical storm
      icon = "<i class='fas fa-poo-storm'></i>";
      break;
    case 2:  //hurricane
      icon = "<i class='fas fa-poo-storm'></i>";
      break;
    case 3:  //severe thunderstorms
      icon = "<i class='fas fa-bolt-lightning'></i>";
      break;
    case 4:  //thunderstorms
      icon = "<i class='fas fa-bolt-lightning'></i>";
      break;
    case 5:  //mixed rain and snow
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 6:  //mixed rain and sleet
      icon = "<i class='fas fa-icicles'></i>";
      break;
    case 7:  //mixed snow and sleet
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 8:  //freezing drizzle
      icon = "<i class='fas fa-icicles'></i>";
      break;
    case 9:  //drizzle
      icon = "<i class='fas fa-cloud-rain'></i>";
      break;
    case 10: //freezing rain
      icon = "<i class='fas fa-icicles'></i>";
      break;
    case 11: //showers
      icon = "<i class='fas fa-cloud-rain'></i>";
      break;
    case 12: //showers
      icon = "<i class='fas fa-cloud-rain'></i>";
      break;
    case 13: //snow flurries
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 14: //light snow showers
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 15: //blowing snow
      icon = "<i class='fas fa-wind'></i>";
      break;
    case 16: //snow
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 17: //hail
      icon = "<i class='fas fa-icicles'></i>";
      break;
    case 18: //sleet
      icon = "<i class='fas fa-icicles'></i>";
      break;
    case 19: //dust
      icon = "<i class='fas fa-water'></i>";
      break;
    case 20: //foggy
      icon = "<i class='fas fa-smog'></i>";
      break;
    case 21: //haze
      icon = "<i class='fas fa-smog'></i>";
      break;
    case 22: //smoky
      icon = "<i class='fas fa-smog'></i>";
      break;
    case 23: //blustery
      icon = "<i class='fas fa-wind'></i>";
      break;
    case 24: //windy
      icon = "<i class='fas fa-wind'></i>";
      break;
    case 25: //cold
      icon = "<i class='fas fa-temperature-low'></i>";
      break;
    case 26: //cloudy
      icon = "<i class='fas fa-cloud'></i>";
      break;
    case 27: //mostly cloudy (night)
      icon = "<i class='fas fa-cloud-moon'></i>";
      break;
    case 28: //mostly cloudy (day)
      icon = "<i class='fas fa-cloud-sun'></i>";
      break;
    case 29: //partly cloudy (night)
      icon = "<i class='fas fa-cloud-moon'></i>";
      break;
    case 30: //partly cloudy (day)
      icon = "<i class='fas fa-cloud-sun'></i>";
      break;
    case 31: //clear (night)
      icon = "<i class='fas fa-moon'></i>";
      break;
    case 32: //sunny
      icon = "<i class='fas fa-sun'></i>";
      break;
    case 33: //fair (night)
      icon = "<i class='fas fa-moon'></i>";
      break;
    case 34: //fair (day)
      icon = "<i class='fas fa-sun'></i>";
      break;
    case 35: //mixed rain and hail
      icon = "<i class='fas fa-cloud-showers-heavy'></i>";
      break;
    case 36: //hot
      icon = "<i class='fas fa-temperature-high'></i>";
      break;
    case 37: //isolated thunderstorms
      icon = "<i class='fas fa-bolt-lightning'></i>";
      break;
    case 38: //scattered thunderstorms
      icon = "<i class='fas fa-bolt-lightning'></i>";
      break;
    case 39: //scattered thunderstorms
      icon = "<i class='fas fa-bolt-lightning'></i>";
      break;
    case 40: //scattered showers
      icon = "<i class='fas fa-cloud-showers-heavy'></i>";
      break;
    case 41: //heavy snow
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 42: //scattered snow showers
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 43: //heavy snow
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 44: //partly cloudy
      icon = "<i class='fas fa-cloud-sun'></i>";
      break;
    case 45: //thundershowers
      icon = "<i class='fas fa-cloud-showers-heavy'></i>";
      break;
    case 46: //snow showers
      icon = "<i class='fas fa-snowflake'></i>";
      break;
    case 47: //isolated thundershowers
      icon = "<i class='fas fa-cloud-showers-heavy'></i>";
      break;
    case 3200: //not available
      icon = "<i class='fas fa-umbrella'></i>";
      break;
    default:
      icon = "";
  }
  return icon;
}
function batteryIcon(percent) {
  let icon;
  if(percent <= 20) {
    icon = "<i class='fas fa-battery-empty'></i>";
  } else if (percent > 20 && percent <= 40) {
    icon = "<i class='fas fa-battery-quarter'></i>";
  } else if (percent > 40 && percent <= 60) {
    icon = "<i class='fas fa-battery-half'></i>";
  } else if (percent > 60 && percent <= 80) {
    icon = "<i class='fas fa-battery-three-quarters'></i>";
  } else if (percent > 80) {
    icon = "<i class='fas fa-battery-full'></i>";
  }
  return icon;
}
function unixTSConvert(timestamp, type) {
  formatted = new Date(timestamp * 1000);
  switch(type){
    case "time":
      if (Clock == "24h"){
        return formatted.getHours() + ":" + formatted.getMinutes() + ((formatted.getHours() > 12 ) ? " pm" : " am");
      }
      if (Clock == "12h"){
        return ((formatted.getHours() > 12) ? formatted.getHours()-12 : formatted.getHours()) + ":" + formatted.getMinutes() + ((formatted.getHours() > 12 ) ? " pm" : " am");
      }
      break;
    default:
      return null;
  }
}
function updateClock() {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h"){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}
if (Clock == "12h"){
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}
document.getElementById('hour').innerHTML = currentHours;
document.getElementById('minute').innerHTML = currentMinutes;
}

function init(){
  updateClock();
  setInterval("updateClock();", 1000);
}
