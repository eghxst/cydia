(function(){
    'use strict';
    if (window.innerWidth === 320) {
        document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=0.85, maximum-scale=0.85, user-scalable=0');
    } else if (window.innerWidth === 414) {
        document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.104, maximum-scale=1.104, user-scalable=0');
    } else if (window.innerWidth === 425) {
        document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.133, maximum-scale=1.133, user-scalable=0');
    } else if (window.innerWidth === 432) {
        document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.152, maximum-scale=1.152, user-scalable=0');
    }
}());
function mainUpdate(type){
    if (type == "weather"){ //weather info
      document.getElementById('weather').innerHTML = weather.temperature + "&deg;";
		}
    if(type == "battery") {
      document.getElementById('battery').innerHTML = batteryPercent + "%";
    }

}
