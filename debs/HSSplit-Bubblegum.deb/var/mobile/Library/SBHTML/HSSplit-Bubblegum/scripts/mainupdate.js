function mainUpdate(type){
		if(type == "reminders"){ //reminder info
			var currentTime = new Date();
			var currentMonth = (currentTime.getMonth()+1);
			var formatMonth = (currentMonth < 10) ? "0"+currentMonth : currentMonth;
			var today = formatMonth + "/" + currentTime.getDate() + "/" + currentTime.getFullYear();
			document.getElementById('reminders').innerHTML = "<h2><i class='fas fa-star' class='shadow'></i>Remember!</h2><ul><div id='reminderitems'></div></ul>";
			let listitems = document.getElementById('reminderitems');
			let located = false;
			for(let i = 0; i < reminders.length; i++) {
				if(located) break;
				else if(reminders[i].dueDate === today) {
					located = true;
					var dueTime = unixTSConvert(reminders[i].dueDateTimestamp, "time");
					listitems.innerHTML += "<li><a class='title'>" + reminders[i].title+"</a> <a class='shadow'>Due: "+ dueTime + " </a></li>";
				}
			}
		}
		if(type == "events"){ //events info
			var currentTime = new Date();
			var currentMonth = (currentTime.getMonth()+1);
			var formatMonth = (currentMonth < 10) ? "0"+currentMonth : currentMonth;
			var today = formatMonth + "/" + currentTime.getDate() + "/" + currentTime.getFullYear();
			document.getElementById('events').innerHTML = "<h2>Today</i></h2><ul><div id='listitems'></div></ul>";
			let len = (events.length > EventsToShow) ? EventsToShow : events.length;
			let listDiv = document.getElementById('listitems');
			for(let i = 0; i < len; i++) {
				if(events[i].date === today) {
					var startTime = unixTSConvert(events[i].startTimeTimestamp, "time"),
							endTime = unixTSConvert(events[i].endTimeTimestamp, "time");
					var duration;
					if(startTime == "0:00 am" && endTime == "11:59 pm" || events[i].isAllDay)
						duration = "All Day";
					else
						duration = startTime + " - " + endTime;
					listitems.innerHTML += "<li><a class='shadow'>"+ duration + " </a><br> <a class='title'>" + events[i].title+"</a></li>";
				}
			}

		}
		if (type == "weather"){ //weather info
			document.getElementById('temp').innerHTML = conditionIcon(weather.conditionCode) + weather.temperature + "<a class='shadow'>&deg;</a>";
			document.getElementById('location').innerHTML = weather.address.city;
		}
	}
  (function(){
      'use strict';
      if (window.innerWidth === 320) {
          document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=0.85, maximum-scale=0.85, user-scalable=0');
      } else if (window.innerWidth === 414) {
          document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.104, maximum-scale=1.104, user-scalable=0');
      } else if (window.innerWidth === 425) {
          document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.133, maximum-scale=1.133, user-scalable=0');
      } else if (window.innerWidth === 432) {
          document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=1.152, maximum-scale=1.152, user-scalable=0');
      }
  }());
