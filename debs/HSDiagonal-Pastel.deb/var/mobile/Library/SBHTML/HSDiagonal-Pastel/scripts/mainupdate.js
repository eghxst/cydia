function mainUpdate(type){
let batteryDiv = document.getElementById('battery'),
    eventsDiv = document.getElementById('events'),
    weatherDiv = document.getElementById('weather');
      if(type == "battery"){ //battery info
        batteryDiv.innerHTML = batteryPercent + "%<br>" + batteryIcon(batteryPercent);
  		}
      if(type == "events"){ //events info
          var currentTime = new Date();
          var currentMonth = (currentTime.getMonth()+1);
          var formatMonth = (currentMonth < 10) ? "0"+currentMonth : currentMonth;
          var today = formatMonth + "/" + currentTime.getDate() + "/" + currentTime.getFullYear();
          eventsDiv.innerHTML = "<h2>Today</i></h2><ul><div id='listitems'></div></ul>";
          let len = (events.length > EventsToShow) ? EventsToShow : events.length;
          let listDiv = document.getElementById('listitems');
          for(let i = 0; i < len; i++) {
            if(events[i].date === today) {
              var startTime = unixTSConvert(events[i].startTimeTimestamp, "time"),
                  endTime = unixTSConvert(events[i].endTimeTimestamp, "time");
              var duration;
              if(startTime == "0:00 am" && endTime == "11:59 pm")
                duration = "All Day";
              else
                duration = startTime + " - " + endTime;
              listitems.innerHTML += "<li>"+ duration + " <br> <a class='title'>" + events[i].title+"</a></li>";
            }
          }
		}
    if (type == "weather"){ //weather info
      weatherDiv.innerHTML = weather.temperature + "&deg;<br>" + conditionIcon(weather.conditionCode);
		}

}
